package com.anthem.aso.rmbservice.filters.pre;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;

@Component
public class PreFilter extends ZuulFilter {
    private static Logger log = LoggerFactory.getLogger(PreFilter.class);

    @Value("${rmb.username}")
	private String username;
	@Value("${rmb.password}")
	private String password;
	
    @Override
    public String filterType() {
        return "pre";
    }

    @Override
    public int filterOrder() {
        return 1;
    }

    @Override
    public Object run() {
        RequestContext ctx = RequestContext.getCurrentContext();
        HttpServletRequest request = ctx.getRequest();

        Map<String, String> headerMap = getHeadersInfo(request);
        
        //Authorization header when the endpoint is directly called from gateway endpoint or actual endpoint
        String localAuthentication = headerMap.get("authorization");
        
        //Authorization header when the endpoint is called from UI where the user is authenticated & authorized from SSO
        //TODO: Check if the header value would be "SM_USERDN" or "SM_USER"
        String ssoAuthorization = headerMap.get("SM_USER");
         
        //Both cases users are authenticated and authorized
        if (	( (ssoAuthorization != null) && (!ssoAuthorization.isEmpty()) ) ||
        		( (localAuthentication != null) && (!localAuthentication.isEmpty()) ) 
           ) 
        	ctx.addZuulRequestHeader("Authorization", "Basic " + getBase64Encoded());
        
        log.info(String.format("%s request to %s", request.getMethod(), request.getRequestURL().toString()));
        return null;
    }
    
    
    @Override
    public boolean shouldFilter() {
        RequestContext ctx = RequestContext.getCurrentContext();
        //String requestUri = ctx.getRequest().getRequestURI();
        
        return true;
    }
    
    
    /**
	 * @return Base64 encoded UserName and Password for authentication
	 */
	public String getBase64Encoded() {
		String credentials = username + ":" + password;
		byte[] credentialsBytes = credentials.getBytes();
		byte[] base64CredsBytes = Base64.encodeBase64(credentialsBytes);

		String base64Creds = new String(base64CredsBytes);
		return base64Creds;
	}
	
	private Map<String, String> getHeadersInfo(HttpServletRequest request) {

		Map<String, String> map = new HashMap<String, String>();

		Enumeration<String> headerNames = request.getHeaderNames();
		while (headerNames.hasMoreElements()) {
			String key = (String) headerNames.nextElement();
			String value = request.getHeader(key);
			map.put(key, value);
		}

		return map;
	}
    
}
