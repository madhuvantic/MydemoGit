package com.anthem.aso.rmbservice;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.web.SpringBootServletInitializer;
import org.springframework.cloud.netflix.zuul.EnableZuulProxy;
import org.springframework.context.annotation.Bean;

import com.anthem.aso.rmbservice.filters.pre.PreFilter;

@SpringBootApplication
@EnableZuulProxy
public class ApiGatewayApplication extends SpringBootServletInitializer {

	
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(ApiGatewayApplication.class);
	}
	
	
    @Bean
    public PreFilter preFilter() {
        return new PreFilter();
    }
}
