package com.anthem.aso.services.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.Resource;

public class ResourceLoaderUtil {
	
	@SuppressWarnings("resource")
	public ArrayList<String> loadJSONFile() throws IOException {

		ArrayList<String> dynList = new ArrayList<String>();
		ApplicationContext appContext = new ClassPathXmlApplicationContext(new String[] {});

		Resource resource = appContext.getResource("classpath:accounts.json");
		String jsonString = null;
		String[] dynListArr = null;
		try {
			InputStream is = resource.getInputStream();
			BufferedReader br = new BufferedReader(new InputStreamReader(is));

			while ((jsonString = br.readLine()) != null) {
				dynListArr = jsonString.split("}]}");
				dynList.add(dynListArr[0]);
			}
			br.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
		return dynList;
	}
	
}
	

