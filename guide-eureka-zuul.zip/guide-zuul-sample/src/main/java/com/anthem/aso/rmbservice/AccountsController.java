package com.anthem.aso.rmbservice;

import java.io.IOException;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import org.apache.commons.codec.binary.Base64;
import java.util.List;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.anthem.aso.services.model.AccountsResponse;
import com.anthem.aso.services.model.BillingAccounts;


@RestController
public class AccountsController {

	@RequestMapping(method = RequestMethod.GET, produces = "application/json",value ="/cust/{accountNumber}/accounts")
	public AccountsResponse getCustomerDetails(@PathVariable String accountNumber) throws IOException {

		AccountsResponse ar = getMockAccountsReponse();		
		return ar;
	}

	private AccountsResponse getMockAccountsReponse() {
		
		List<BillingAccounts> baList = new ArrayList<BillingAccounts>();
		
		BillingAccounts ba1 = new BillingAccounts();
		ba1.setId("1234567890");
		ba1.setName("Billing Account 1");
		baList.add(ba1);
		
		BillingAccounts ba2 = new BillingAccounts();
		ba2.setId("4321878890");
		ba2.setName("Billing Account 2");
		baList.add(ba2);
		
		BillingAccounts ba3 = new BillingAccounts();
		ba3.setId("9934511823");
		ba3.setName("Billing Account 3");
		baList.add(ba3);
		
		BillingAccounts ba4 = new BillingAccounts();
		ba4.setId("7734567855");
		ba4.setName("Billing Account 4");
		baList.add(ba4);
		
		
		final String uri = "http://mom9n10041.wellpoint.com:8089/cust/5361747723/accounts";   
	    RestTemplate restTemplate = new RestTemplate();
	    
	   
	    HttpHeaders headers = new HttpHeaders();
        headers.setContentType( MediaType.APPLICATION_JSON );
        
        String username = "JNDI";
		String password = "T26NA7it4eFD";
	    byte[] credentials = Base64.encodeBase64((username + ":" + password).getBytes(StandardCharsets.UTF_8));
	    headers.add("Authorization", "Basic " + new String(credentials, StandardCharsets.UTF_8));
	    
	    
        HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
        ResponseEntity<AccountsResponse> result = restTemplate.exchange(uri, HttpMethod.GET, entity, AccountsResponse.class);
        System.out.println("Result = " + result);
		
		return new AccountsResponse("123789", baList);
		
		
	}
	
	
	
}

