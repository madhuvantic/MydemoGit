package com.anthem.aso.services.model;

import java.util.ArrayList;
import java.util.List;


public class AccountsResponse {

	private String customer_ID;
	private List<BillingAccounts> accounts;

	public AccountsResponse() {
		
	}
	
	public AccountsResponse(String customerId, List<BillingAccounts> accounts) {
		super();
		this.customer_ID = customerId;
		this.accounts = accounts;
	}

	
	public String getCustomer_ID() {
		return customer_ID;
	}


	public void setCustomer_ID(String customer_ID) {
		this.customer_ID = customer_ID;
	}


	public List<BillingAccounts> getAccounts() {
		return accounts;
	}

	public void setAccounts(ArrayList<BillingAccounts> accounts) {
		this.accounts = accounts;
	}

}
