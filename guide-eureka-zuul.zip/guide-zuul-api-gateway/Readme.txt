Start the actual API from guide-zuul-movie
http://localhost:9000/ghostbusters/


Proxy API URL from guide-zuul-api-gateway
http://localhost:8080/movies/ghostbusters/